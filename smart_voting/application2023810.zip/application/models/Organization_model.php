<?php

class organization_model extends CI_Model {

    function __construct()    {
        parent::__construct();
    }

    function get_current_priceid(){
    	$sql = "SELECT * FROM payment_config ORDER BY price_id DESC limit 1";
    	$query = $this->db->query($sql);
    	if($query->num_rows()>0){
    		return $query->row()->price_id;
    	}else{
    		return 0;
    	}
    }

    function save_organization($orgarr){
    	$this->db->insert('organization',$orgarr);
    	return $this->db->insert_id();
    }

    function insert_org_payment($orgpaymentarr){
    	return $this->db->insert('org_registration_payment',$orgpaymentarr);
    }

    function get_all_organization_list(){
    	$this->db->select('*');
    	$this->db->from('organization');
    	$query = $this->db->get();
    	if($query->num_rows()>0){
    		return $query->result();
    	}else{
    		return [];
    	}
    }

    function check_org_admin_exist($org_id){
    	$this->db->where('org_id',$org_id);
    	$query = $this->db->get('org_member_users');
    	if($query->num_rows()>0){
    		return 1;
    	}else{
    		return 0;
    	}
    }

    function save_organization_admin($orgadminarr){
    	return $this->db->insert('org_member_users',$orgadminarr);
    }

}    