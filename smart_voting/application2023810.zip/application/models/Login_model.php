<?php

class Login_model extends CI_Model {

    function __construct()    {
        parent::__construct();
    }

    function check_login($un,$pw){
      $sql = "SELECT * FROM site_admin WHERE main_username='$un' AND main_password='$pw' AND main_active_stts=1";
      $query = $this->db->query($sql);
      if($query->num_rows()>0){
      	$loginarr['status'] = 1;
      	$loginarr['admin_name'] = $query->row()->full_name;
      	$loginarr['user_id'] = $query->row()->main_user_id;
      	return $loginarr;
      }else{
      	$loginarr['status'] = 0;
      	$loginarr['admin_name'] = "";
      	$loginarr['user_id'] = "";
      	return $loginarr;
      }

    }
    

    function save_admin($insertadminarr){
    	return $this->db->insert('site_admin',$insertadminarr);
    }


}