<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Organization extends CI_Controller {


	public function index()
	{
		$this->is_logged();
		$orglist = $this->organization_model->get_all_organization_list();
		$mainarr = [];
        foreach ($orglist as $org) {
        	$subarr['org_id'] = $org->org_id;
        	$subarr['org_name'] = $org->org_name;
        	$subarr['contact_no'] = $org->contact_no;
        	$subarr['address'] = $org->address;
        	$subarr['org_code'] = $org->org_code;
        	$subarr['is_admin_creted'] = $this->organization_model->check_org_admin_exist($org->org_id);
        	array_push($mainarr,$subarr);
        }

		$data['orglist'] = $mainarr;
		//print_r($data['orglist']);
		$this->load->view('admin/create_organization',$data);
	}

    function save_organization(){
    	$orgname = $this->input->post('orgname');
    	$contno = $this->input->post('contno');
    	$org_address = $this->input->post('org_address');
    	$org_mail = $this->input->post('org_mail');
    	$prefixcode = $this->input->post('prefixcode');

    	//get current price..
        $priceid = $this->organization_model->get_current_priceid();

 		$orgarr['org_name'] = $orgname;
		$orgarr['contact_no'] = $contno;
		$orgarr['address'] = $org_address;
		$orgarr['email_address'] = $org_mail;
		$orgarr['created_by'] = $this->session->userdata('userid');
		$orgarr['created_on'] = date("Y-m-d");
		$orgarr['active_stts'] = 1;
		$orgarr['org_code'] = $prefixcode;

		$orgid = $this->organization_model->save_organization($orgarr);
		//get current date
		$currentdate = date("Y-m-d");

		//week remainder date..
        $weekremainderdate = date('Y-m-d', strtotime($currentdate. ' + 358 days'));

		// expire date ..
        $expiredate = date('Y-m-d', strtotime($currentdate. ' + 365 days'));

		$orgpaymentarr['org_id'] = $orgid;
		$orgpaymentarr['register_from'] = $currentdate;
		$orgpaymentarr['register_to'] = $expiredate;
		$orgpaymentarr['payment_stts'] = 1;
		$orgpaymentarr['price_id'] = $priceid; 
		$orgpaymentarr['week_remainder_date'] = $weekremainderdate;

		$saveorgpayment = $this->organization_model->insert_org_payment($orgpaymentarr);
        if($orgid && $saveorgpayment){
          $this->session->set_userdata('successmsg', 'Succesfully Created Organization');	
          redirect('organization');
		}else{
		  $this->session->set_userdata('errormsg', 'Error creating Organization');		
		  redirect('organization');
		}


    }

    function create_org_admin(){
    	$this->is_logged();
    	$orgid = $this->uri->segment(3);
    	$prefix = $this->uri->segment(4);
    	$data['orgid'] = $orgid;
    	$adminun = $prefix."admin1";
    	$data['username'] = $adminun;
		$this->load->view('admin/create_org_admin',$data);
    }

    function save_org_admin(){
      
	$orgadminarr['org_id'] = $this->input->post('orgid');
	$orgadminarr['user_full_name'] = $this->input->post('orgadminname');
	$orgadminarr['u_address'] = $this->input->post('org_admin_address');
	$orgadminarr['u_contact_no'] = $this->input->post('org_admin_contno');
	$orgadminarr['u_email_address'] = $this->input->post('org_admin_mail');
	$orgadminarr['u_username'] = $this->input->post('org_admin_username');
	$orgadminarr['u_password'] = md5(sha1($this->input->post('admin_nic')));
	$orgadminarr['u_active_stts'] = 1;
	$orgadminarr['u_created_on'] = date("Y-m-d");
	$orgadminarr['u_created_by'] = $this->session->userdata('userid');
	$orgadminarr['user_type'] = 1;
	$orgadminarr['admin_nic'] = $this->input->post('admin_nic');

	$saveorgadmin = $this->organization_model->save_organization_admin($orgadminarr);
     if($saveorgadmin){
          $this->session->set_userdata('successmsg', 'Succesfully Created Organization Admin');	
          redirect('organization');
		}else{
		  $this->session->set_userdata('errormsg', 'Error creating Organization Admin');		
		  redirect('organization');
		}


    }
    

    function is_logged(){
      if($this->session->userdata('userid')==""){
      	redirect('login');
      }
	}

}	