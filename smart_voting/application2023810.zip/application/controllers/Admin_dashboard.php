<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_dashboard extends CI_Controller {

	public function index()
	{
		$this->is_logged();
		$this->load->view('admin/admin_dashboard_view');
	}

    function create_admin(){
    	$this->is_logged();
		$this->load->view('admin/create_admin_view');
    }

    function save_admin(){
    	$fullname = $this->input->post('fullname');
    	$username = $this->input->post('username');
    	$password = md5(sha1($this->input->post('password')));
 	
		$insertadminarr['full_name'] = $fullname;
		$insertadminarr['user_type'] = 1;
		$insertadminarr['main_username'] = $username;
		$insertadminarr['main_password'] = $password;
		$insertadminarr['main_active_stts'] = 1;

		$savestts=$this->login_model->save_admin($insertadminarr);
		if($savestts){
		  $this->session->set_userdata('successmsg', 'Succesfully Saved');	
          redirect('admin_dashboard/create_admin');
		}else{
		  $this->session->set_userdata('errormsg', 'Error saving data');		
		  redirect('admin_dashboard/create_admin');
		}

    }






	function is_logged(){
      if($this->session->userdata('userid')==""){
      	redirect('login');
      }
	}
}
